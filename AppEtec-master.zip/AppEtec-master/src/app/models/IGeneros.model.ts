export interface IGeneros{
    genres: [
      {
        id: number;
        name: string;
      }
    ];
}
